#!/bin/bash

COLOR="#888888"
exec i3lock -c $COLOR
